package com.comision5.salvo;

import com.comision5.salvo.clases.*;
import com.comision5.salvo.restrepositories.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api")
public class SalvoController {

  @Autowired
  private GameRepository gameRepo;

  @Autowired
  private PlayerRepository playerRepo;

  @Autowired
  private GamePlayerRepository gamePlayerRepo;


  @RequestMapping("/games")
  public List<Object> gamesInfo() {
    return gameRepo.findAll().stream().map(Game::gameDTO).collect(Collectors.toList());
  }

  @RequestMapping("/game_view/{id}")
  private Map<String, Object> gameView(@PathVariable long id) {

    return gamePlayerRepo.findById(id).get().gamePlayerDTO();
  }

  //No es extrictamente necesario pero es el otro camino para crear la tabla de puntajes
  @RequestMapping("/leaderboard")
  public List<Object> lederboardInfo(){
    return playerRepo.findAll().stream().map(Player::leaderBoardDTO).collect(Collectors.toList());
  }

  //Pedido especial para generar una lista en el DOM, solo por facilidad propia dado que soy amo y señor de este proyecto
  @RequestMapping("/gamePlayerIds")
  private List<Object> gamePlayerIds() {
    return gamePlayerRepo.findAll().stream().map(GamePlayer::getId).collect(Collectors.toList());
  }

}