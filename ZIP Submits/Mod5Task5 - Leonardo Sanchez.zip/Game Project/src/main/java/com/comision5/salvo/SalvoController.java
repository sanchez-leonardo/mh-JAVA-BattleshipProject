package com.comision5.salvo;

import com.comision5.salvo.clases.*;
import com.comision5.salvo.restrepositories.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api")
public class SalvoController {

  @Autowired
  private GameRepository gameRepo;

  @Autowired
  private PlayerRepository playerRepo;

  @Autowired
  private GamePlayerRepository gamePlayerRepo;

  @Autowired
  private ShipRepository shipRepo;

  @Autowired
  SalvoRepository salvoRepo;

  @Autowired
  private PasswordEncoder passwordEncoder;


  //Llamado para crear la tabla de puntajes
  @GetMapping("/leaderboard")
  public List<Object> lederboardInfo() {
    return playerRepo.findAll().stream().map(Player::leaderBoardDTO).collect(Collectors.toList());
  }

  //Info general de todos los juegos
  @GetMapping("/games")
  public Map<String, Object> gamesInfo(Authentication auth) {

    Map<String, Object> gamesInfoDTO = new LinkedHashMap<>();

    gamesInfoDTO.put("currentUser", isGuest(auth) ? null : playerRepo.findByUserName(auth.getName()).playerDetail());
    gamesInfoDTO.put("games", gameRepo.findAll().stream().map(Game::gameDTO).collect(Collectors.toList()));

    return gamesInfoDTO;
  }

  //Game player específico
  @GetMapping("/game_view/{gpId}")
  public ResponseEntity<Object> gameView(@PathVariable long gpId, Authentication auth) {

    if (isGuest(auth)) {

      return new ResponseEntity<>("you are not a user", HttpStatus.UNAUTHORIZED);

    } else if (!gamePlayerExists(gpId)) {

      return new ResponseEntity<>("no such game", HttpStatus.NOT_FOUND);

    } else if (!samePlayer(gpId, auth)) {

      return new ResponseEntity<>("you can not see that", HttpStatus.FORBIDDEN);

    } else {

      return new ResponseEntity<>(gamePlayerRepo.findById(gpId).get().gamePlayerDTO(), HttpStatus.ACCEPTED);

    }
  }

  //Registro de usuario
  @PostMapping(path = "/players")
  public ResponseEntity<Object> register(
          @RequestParam String userName, @RequestParam String password) {

    if (userName.isEmpty() || password.isEmpty()) {

      return new ResponseEntity<>("Missing data", HttpStatus.FORBIDDEN);

    } else if (playerRepo.findByUserName(userName) != null) {

      return new ResponseEntity<>("Email already in use", HttpStatus.FORBIDDEN);

    } else {

      playerRepo.save(new Player(userName, passwordEncoder.encode(password)));
      return new ResponseEntity<>(HttpStatus.CREATED);

    }
  }

  //Creación de juego
  @PostMapping(path = "/games")
  public ResponseEntity<Object> createGame(Authentication auth) {

    if (isGuest(auth)) {

      return new ResponseEntity<>("you are not a user", HttpStatus.FORBIDDEN);

    } else {

      Game newGame = new Game();
      gameRepo.save(newGame);

      Player thePlayer = playerRepo.findByUserName(auth.getName());

      GamePlayer aNewGP = new GamePlayer(thePlayer, newGame);
      gamePlayerRepo.save(aNewGP);

      newGame.setGamePlayers(Collections.singletonList(aNewGP));
      thePlayer.addGamePlayer(aNewGP);

      return new ResponseEntity<>(responseObject("gpId", aNewGP.getId()), HttpStatus.CREATED);
    }

  }

  //Entrada a juego existente
  @PostMapping(path = "/game/{gameId}/players")
  public ResponseEntity<Object> joinGame(@PathVariable Long gameId, Authentication auth) {

    Player thePlayer = playerRepo.findByUserName(auth.getName());

    if (isGuest(auth)) {

      return new ResponseEntity<>("greetings, program", HttpStatus.UNAUTHORIZED);

    } else if (!optGame(gameId).isPresent()) {

      return new ResponseEntity<>("this is not the game you are looking for", HttpStatus.FORBIDDEN);

    } else if (optGame(gameId).get().getGamePlayers().size() > 1) {

      return new ResponseEntity<>("place is crowded", HttpStatus.FORBIDDEN);

    } else if (isAlreadyPlayer(optGame(gameId).get(), thePlayer)) {

      return new ResponseEntity<>("playing with yourself", HttpStatus.FORBIDDEN);

    } else {

      Game existingGame = gameRepo.findById(gameId).get();

      GamePlayer aNewGP = new GamePlayer(thePlayer, existingGame);
      gamePlayerRepo.save(aNewGP);

      existingGame.addGamePlayer(aNewGP);
      thePlayer.addGamePlayer(aNewGP);

      return new ResponseEntity<>(responseObject("gpId", aNewGP.getId()), HttpStatus.CREATED);

    }

  }

  //Creación de lista de barcos de gamePlayer
  @PostMapping(path = "/games/players/{gpId}/ships")
  public ResponseEntity<Object> setGamePlayerShips(@PathVariable Long gpId, @RequestBody List<Ship> ships, Authentication auth) {

    if (isGuest(auth)) {

      return new ResponseEntity<>("greetings, program", HttpStatus.UNAUTHORIZED);

    } else if (!gamePlayerExists(gpId)) {

      return new ResponseEntity<>("no such game", HttpStatus.UNAUTHORIZED);

    } else if (!samePlayer(gpId, auth)) {

      return new ResponseEntity<>("ye can't sail yer ships thar", HttpStatus.UNAUTHORIZED);

    } else if (ships.size() > 5) {

      return new ResponseEntity<>("too many ships in your fleet", HttpStatus.FORBIDDEN);

    } else {

      List<Ship> shipList = new ArrayList<>();

      ships.stream().forEach(vessel -> {

        Ship newShip = new Ship(vessel.getShipType(), vessel.getShipLocations(), gamePlayerRepo.findById(gpId).get());

        shipList.add(newShip);

      });

      shipRepo.saveAll(shipList);

      gamePlayerRepo.findById(gpId).get().setShips(shipList);

      return new ResponseEntity<>("ships placed", HttpStatus.CREATED);

    }
  }

  //Creación de lista de salvoes de gamePlayer
  @PostMapping(path = "/games/players/{gpId}/salvoes")
  public ResponseEntity<Object> setGamePlayerSalvoes(
          @PathVariable Long gpId,
          @RequestBody List<String> salvoes, Authentication auth) {

    if (isGuest(auth)) {

      return new ResponseEntity<>("greetings, program", HttpStatus.UNAUTHORIZED);

    } else if (!gamePlayerExists(gpId)) {

      return new ResponseEntity<>("no such game", HttpStatus.FORBIDDEN);

    } else if (!samePlayer(gpId, auth)) {

      return new ResponseEntity<>("keep yer cannonballs to yerself", HttpStatus.UNAUTHORIZED);

    } else if (salvoes.size() > 5) {

      return new ResponseEntity<>("too many shots", HttpStatus.FORBIDDEN);

    } else {

      //temporalmente usa los elementos del objeto para establecer el turno
      //Debería ser un contador según el estado de juego
      if (gamePlayerRepo.findById(gpId).get().getSalvoes().size() == 0) {

        Salvo newSalvo = new Salvo(1, salvoes, gamePlayerRepo.findById(gpId).get());

        salvoRepo.save(newSalvo);

        gamePlayerRepo.findById(gpId).get().addSalvo(newSalvo);

        return new ResponseEntity<>("salvoes placed", HttpStatus.CREATED);

      } else if (gamePlayerRepo.findById(gpId).get().getSalvoes().size() != 0) {

        Salvo newSalvo = new Salvo(
                gamePlayerRepo.findById(gpId).get().getSalvoes().size() + 1,
                salvoes,
                gamePlayerRepo.findById(gpId).get());

        salvoRepo.save(newSalvo);

        gamePlayerRepo.findById(gpId).get().addSalvo(newSalvo);

        return new ResponseEntity<>("salvoes placed", HttpStatus.CREATED);

      } else {

        return new ResponseEntity<>("Something didn't work", HttpStatus.FORBIDDEN);

      }
    }

  }


  //AUX
  //Retorna true si no es usuario autentificado o es annonymous
  private boolean isGuest(Authentication auth) {
    return auth == null || auth instanceof AnonymousAuthenticationToken;
  }

  //Boolean si el player id es igual al id del player en el gameplayer pedido
  private boolean samePlayer(Long id, Authentication auth) {
    return gamePlayerRepo.findById(id).get().getPlayer().getId() == playerRepo.findByUserName(auth.getName()).getId();
  }

  //Boolean para comprobar que un game no tiene al jugador que quiere unirse
  private boolean isAlreadyPlayer(Game game, Player player) {

    return game.getGamePlayers().stream()
            .map(gp -> gp.getPlayer().getId()).collect(Collectors.toList())
            .contains(player.getId());

  }

  //Boolean para comprobar si existe el game player
  private boolean gamePlayerExists(Long id) {
    return gamePlayerRepo.findById(id).isPresent();
  }

  //Retorna un objeto simple de 1 campo
  private Map<String, Object> responseObject(String key, Object value) {

    Map<String, Object> responseObj = new LinkedHashMap<>();

    responseObj.put(key, value);

    return responseObj;
  }

  //Retorna el optional de game. Es para simplificar comparaciones
  private Optional<Game> optGame(Long id) {
    return gameRepo.findById(id);
  }

}