//log out fetch
function logOut(evt) {
  evt.preventDefault();

  postingFetch('/api/logout')
    .then(data => {
      if (data.ok) {
        location.href = '/web/boarding_page.html';
      }
    })
    .catch(error => console.log(error));
}

//Log out
let logOutBtn = document.getElementById('logOutBtn');
logOutBtn.addEventListener('click', logOut);

//create game fetch
function createGame() {
  fetch('/api/games', { method: 'POST' })
    .then(response => {
      if (response.ok) {
        response.json().then(body => {
          goToGame(body.gpId);
        });
      } else {
        alert('Something went south, try again later');
      }
    })
    .catch(error => console.log(error));
}

//-------------------------------------------------------------------------------------------------

//Botón de creación de juegos
let gameCreator = document.getElementById('gameCreator');
gameCreator.addEventListener('click', createGame);

//join game fetch
function joinGame(gameId) {
  fetch('/api/game/' + gameId + '/players', { method: 'POST' })
    .then(response => {
      if (response.ok) {
        response.json().then(body => {
          goToGame(body.gpId);
        });
      } else {
        alert("Yeah... couldn't. Try again some other time");
      }
    })
    .catch(error => console.log(error));
}

//go to game
function goToGame(gpId) {
  window.location.search = `gp=${gpId}`;
}

//-----------------------------------------------------------------------------------

//Fetch de Games Info, creación de la tabla de juegos y agrega el nombre de usuario al header
//Variable de datos
let gamesCallData;

function gamesInfo() {
  fetch('/api/games')
    .then(response => response.json())
    .then(data => {
      gamesCallData = data;
      currentGamesList(gamesCallData);
      document.getElementById('playerSpan').innerText =
        gamesCallData.currentUser.email;
    })
    .catch(error => console.log(error));
}

//-----------------------------------------------------------------------------------

//Creación de tabla de juegos en curso
//OK, el asunto es así:
// De la información de /api/games va a hacer una tabla, cada fila va a ser uno de los juegos.
// Va a extraer los nombres de los jugadores de cada game player.
// Después, si hay solo 1 game player, crea una celda vacía para mantener el orden de la tabla.
// Luego de crear la celda de la fecha de creación, crea una celda más para el botón de unirse;
// Si el partido esta completo (esta lógica es al momento del task 2), y si el usuario no participa,
// anota que la partida esta llena. Si el usuario participa del juego, crea un boton que lo envía a ese game_view
// extrayendo el GPID de la iteración del bucle.
// Si hay un solo game player, el boton dirá de unirse y su acción sera de crear un juego en el servidor e ir a el
// game_view respectivo

function currentGamesList(data) {
  let tableBody = document.getElementById('gamesList');

  data.games.forEach(game => {
    let gameRow = document.createElement('tr');

    let gameId = document.createElement('td');
    gameId.innerText = game.id;
    gameRow.appendChild(gameId);

    game.game_players.forEach(gp => {
      let player = document.createElement('td');
      player.innerText = gp.player.email;
      gameRow.appendChild(player);
    });

    if (game.game_players.length == 1) {
      gameRow.appendChild(document.createElement('td'));
    }

    let gameCreation = document.createElement('td');
    gameCreation.innerText = game.created;
    gameRow.appendChild(gameCreation);

    let joinCell = document.createElement('td');
    gameRow.appendChild(joinCell);

    let playerInGame = game.game_players
      .map(gp => gp.player.id)
      .includes(data.currentUser.id);

    if (game.game_players.length == 2) {
      if (playerInGame) {
        let joinGameBtn = document.createElement('button');
        joinGameBtn.innerText = 'Re-Join Game';
        joinGameBtn.classList.add('join', 'list-button');

        let gpId = game.game_players.filter(
          gp => gp.player.id == data.currentUser.id
        )[0].id;

        joinGameBtn.setAttribute('onclick', `goToGame(${gpId})`);

        joinCell.appendChild(joinGameBtn);
      } else {
        joinCell.innerHTML = `<p>Game Full</p>`;
      }
    } else {
      let joinGameBtn = document.createElement('button');
      joinGameBtn.innerText = 'Join Game';
      joinGameBtn.classList.add('join', 'list-button');
      joinGameBtn.setAttribute('onclick', `joinGame(${game.id})`);

      joinCell.appendChild(joinGameBtn);
    }

    tableBody.appendChild(gameRow);
  });
}

//-----------------------------------------------------------------------------------

//Si hay query string, lo captura y realiza el pedido de datos
//Almacenaje de datos para prueba
let gpById;

function fetchByQueryString() {
  let queryStringGP = getQueryVariable('gp');

  if (queryStringGP) {
    document.getElementsByClassName('data')[0].classList.toggle('hide');
    document.getElementsByClassName('grids')[0].classList.toggle('hide');

    createGrid('salvos-grid', 's');
    createGrid('player-grid', 'p');

    fetch('/api/game_view/' + queryStringGP)
      .then(response => {
        if (response.ok) {
          response.json().then(data => {
            gpById = data;
            data.ships.forEach(ship => paintThemShips(ship));
            playerNames(data, queryStringGP);
            paintThemSalvoes(data, queryStringGP);
            paintThemHits(data, queryStringGP);
          });
        }
      })
      .catch(error => console.log(error));
  }
}

//-----------------------------------------------------------------------------------

//Función de creación de la grilla, recibe Id de contenedor y target para player o salvo
//Por cada letra crea una linea y le pone id's y clases
function createGrid(id, target) {
  //Contenedor de la grilla
  let grid = document.getElementById(id);
  //Patrón de letras
  let gridLetters = ['0', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j'];

  gridLetters.forEach((letter, i) => {
    let squareLine = document.createElement('div');
    squareLine.setAttribute('class', 'grid-line ' + letter);

    for (i = 0; i < 11; i++) {
      let square = document.createElement('div');
      square.setAttribute('id', target + letter + i);
      square.setAttribute('class', 'grid-square');

      if (
        square.getAttribute('id') == 's00' ||
        square.getAttribute('id') == 'p00'
      ) {
        square.classList.add('blank');
      } else if (letter === '0') {
        square.classList.add('column-name');
        square.innerHTML = `<p>${i}</p>`;
      } else if (i === 0) {
        square.classList.add('column-num');
        square.innerHTML = `<p>${letter.toUpperCase()}</p>`;
      }

      squareLine.appendChild(square);
    }

    grid.appendChild(squareLine);
  });
}

//Función que cambia el color si hay una pieza de barco en player's grid
function paintThemShips(ship) {
  ship.locations.forEach(location => {
    document
      .getElementById('p' + location.toLowerCase())
      .classList.add('ship-piece');
  });
}

//Función que marca salvoes en salvo's grid
function paintThemSalvoes(data, gamePlayerId) {
  let p1Id = data.game_players.filter(
    gp => gp.game_player_id == gamePlayerId
  )[0].player_detail.id;

  Object.entries(data.salvoes[p1Id]).forEach(turn => {
    turn[1].forEach(location => {
      salvoLocation = document.getElementById('s' + location.toLowerCase());
      salvoLocation.classList.add('salvo');
      salvoLocation.innerHTML = `<p>${turn[0]}</p>`;
    });
  });
}

//Función de hits
function paintThemHits(data, gamePlayerId) {
  let p2Id = data.game_players.filter(
    gp => gp.game_player_id != gamePlayerId
  )[0].player_detail.id;

  Object.entries(data.salvoes[p2Id]).forEach(turn => {
    turn[1].forEach(location => {
      hitLocation = document.getElementById('p' + location.toLowerCase());

      if (hitLocation.classList.contains('ship-piece')) {
        hitLocation.classList.add('hit');
        hitLocation.innerHTML = `<p>${turn[0]}</p>`;
      }
    });
  });
}

//Función que coloca nombre de los jugadores
function playerNames(data, gpId) {
  let p1Name = document.getElementById('player1');
  let p2Name = document.getElementById('player2');

  data.game_players.forEach(gp => {
    if (gp.game_player_id == gpId) {
      p1Name.innerText = gp.player_detail.email;
    } else {
      p2Name.innerText = gp.player_detail.email;
    }
  });
}

//-----------------------------------------------------------------------------------

//Utilities

//Funcion generica de posting para register, sign in y log out
async function postingFetch(url, body = '') {
  let init = {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
    },
    body: body
  };

  try {
    const response = await fetch(url, init);
    return response;
  } catch (error) {
    return console.log(error);
  }
}

//Función que captura el valor de una variable del query string
function getQueryVariable(variable) {
  var query = window.location.search.substring(1);
  var vars = query.split('&');
  for (var i = 0; i < vars.length; i++) {
    var pair = vars[i].split('=');
    if (pair[0] == variable) {
      return pair[1];
    }
  }
  return false;
}

//Comprueba que el email sigue las pautas xxx@xxx.xxx
function emailIsValid(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

//-----------------------------------------------------------------------------------

//LLamado a las funciones cuando carga la ventana
window.onload = function() {
  gamesInfo();
  fetchByQueryString();
};
