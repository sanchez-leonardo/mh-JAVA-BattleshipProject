package com.comision5.salvo;

import com.comision5.salvo.clases.*;
import com.comision5.salvo.restrepositories.GamePlayerRepository;
import com.comision5.salvo.restrepositories.GameRepository;
import com.comision5.salvo.restrepositories.SalvoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api")
public class SalvoController {

    @Autowired
    private GameRepository gameRepository;

    @Autowired
    private GamePlayerRepository gamePlayerRepository;

    @Autowired
    private SalvoRepository salvoRepository;

    @RequestMapping("/games")
    public List<Object> gamesInfo() {
        return gameRepository.findAll().stream().map(this::gameDTO).collect(Collectors.toList());
    }

    //Pedido especial para generar una lista en el DOM, solo por facilidad propia dado que soy amo y señor de este proyecto
    @RequestMapping("/gamePlayerIds")
    private List<Object> gamePlayerIds() {
        return gamePlayerRepository.findAll().stream().map(GamePlayer::getId).collect(Collectors.toList());
    }

    @RequestMapping("/game_view/{id}")
    private Map<String, Object> gameView(@PathVariable long id) {

        GamePlayer gamePlayer = gamePlayerRepository.findById(id).get();
        return gamePlayerDTO(gamePlayer);
    }

    //Extraer la info de cada juego
    private Map<String, Object> gameDTO(Game game) {

        Map<String, Object> gameDTO = new LinkedHashMap<>();

        gameDTO.put("id", game.getId());
        gameDTO.put("created", game.getGameTime());
        gameDTO.put("game_players", game.getGamePlayers().stream().map(this::gamePlayerDetail).collect(Collectors.toList()));

        return gameDTO;
    }

    //Extrae gamePlayers Ids, creation y players
    private Map<String, Object> gamePlayerDetail(GamePlayer gamePlayer) {

        Map<String, Object> gamePlayerObj = new LinkedHashMap<>();

        gamePlayerObj.put("id", gamePlayer.getId());
        gamePlayerObj.put("player", playerDetail(gamePlayer.getPlayer()));

        return gamePlayerObj;
    }

    //Extrae Player IDs y Username
    private Map<String, Object> playerDetail(Player player) {

        Map<String, Object> playerObj = new LinkedHashMap<>();

        playerObj.put("id", player.getId());
        playerObj.put("email", player.getUserName());

        return playerObj;
    }

    //Game player data
    private Map<String, Object> gamePlayerDTO(GamePlayer gamePlayer) {

        Map<String, Object> gamePlayerObj = new LinkedHashMap<>();

        gamePlayerObj.put("game_id", gamePlayer.getGame().getId());
        gamePlayerObj.put("game_creation", gamePlayer.getGame().getGameTime());
        gamePlayerObj.put("game_players", gamePlayerArray(gamePlayer.getGame()));
        gamePlayerObj.put("ships", playerShips(gamePlayer.getShips()));
        gamePlayerObj.put("salvoes", salvoesByPlayer(gamePlayer.getGame().getGamePlayers()));

        return gamePlayerObj;

    }

    //Game Player List
    private List<Object> gamePlayerArray(Game game) {

        return game.getGamePlayers().stream().map(gp -> {

            Map<String, Object> gamePlayerObj = new LinkedHashMap<>();

            gamePlayerObj.put("game_player_id", gp.getId());
            gamePlayerObj.put("game_player_join_date", gp.getJoinTime());
            gamePlayerObj.put("player_detail", playerDetail(gp.getPlayer()));

            return gamePlayerObj;
        }).collect(Collectors.toList());

    }

    //Ship List
    private List<Object> playerShips(List<Ship> ships) {

        return ships.stream().map(ship -> {
            Map<String, Object> shipObj = new LinkedHashMap<>();

            shipObj.put("type", ship.getShipType());
            shipObj.put("locations", ship.getShipLocation());

            return shipObj;
        }).collect(Collectors.toList());

    }

    //Salvoes per player object
    private Map<Long, Object> salvoesByPlayer(List<GamePlayer> gamePlayer) {
        //Classic
/*      Map<Long, Object> salvoesObj = new LinkedHashMap<>();

        gamePlayer.stream().forEach(gp -> salvoesObj.put(gp.getPlayer().getId(), salvoesByTurn(gp.getSalvoes())));

        return salvoesObj;*/

        //new and improved
        return gamePlayer.stream().collect(Collectors.toMap(gp -> gp.getPlayer().getId(), gp -> salvoesByTurn(gp.getSalvoes()),
                (s, a) -> s + ", " + a, LinkedHashMap::new));

    }

    //Salvoes per turn object
    private Map<Integer, List<String>> salvoesByTurn(List<Salvo> salvoes) {
        //Classic
        /*Map<Integer, Object> salvoesObj = new LinkedHashMap<>();

        salvoes.stream().forEach(salvo -> salvoesObj.put(salvo.getTurn(), salvo.getSalvoLocations()));

        return salvoesObj;*/

        //new and improved
        return salvoes.stream().collect(Collectors.toMap(Salvo::getTurn, Salvo::getSalvoLocations));

    }

}