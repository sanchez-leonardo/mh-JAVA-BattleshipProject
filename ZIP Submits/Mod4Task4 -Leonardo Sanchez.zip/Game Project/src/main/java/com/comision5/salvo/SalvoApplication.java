package com.comision5.salvo;

import com.comision5.salvo.clases.*;
import com.comision5.salvo.restrepositories.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;


import java.util.Arrays;
import java.util.Date;

@SpringBootApplication
public class SalvoApplication {

    public static void main(String[] args) {
        SpringApplication.run(SalvoApplication.class, args);
    }

    @Bean
    public CommandLineRunner initData(PlayerRepository playerRepository, GameRepository gameRepository,
                                      GamePlayerRepository gamePlayerRepository, ShipRepository shipRepository,
                                      SalvoRepository salvoRepository) {
        return (args) -> {

            //Creación de jugadores y carga al reposiorio
            Player player1 = new Player("j.bauer@ctu.gov", "24");
            Player player2 = new Player("c.obrian@ctu.gov", "42");
            Player player3 = new Player("kim_bauer@gmail.com", "kb");
            Player player4 = new Player("t.almeida@ctu.gov", "mole");

            playerRepository.save(player1);
            playerRepository.save(player2);
            playerRepository.save(player3);
            playerRepository.save(player4);

            //Creación de fecha patron
            Date gameDate = new Date();
            //Creación de juegos defasados por una hora
            Game game1 = new Game(gameDate);
            Game game2 = new Game(Date.from(gameDate.toInstant().plusSeconds(3600)));
            Game game3 = new Game(Date.from(gameDate.toInstant().plusSeconds(7200)));
            Game game4 = new Game(Date.from(gameDate.toInstant().plusSeconds(10800)));
            Game game5 = new Game(Date.from(gameDate.toInstant().plusSeconds(14400)));
            Game game6 = new Game(Date.from(gameDate.toInstant().plusSeconds(18000)));
            Game game7 = new Game(Date.from(gameDate.toInstant().plusSeconds(21600)));
            Game game8 = new Game(Date.from(gameDate.toInstant().plusSeconds(25200)));
            //Guardado de juegos al repositorio
            gameRepository.save(game1);
            gameRepository.save(game2);
            gameRepository.save(game3);
            gameRepository.save(game4);
            gameRepository.save(game5);
            gameRepository.save(game6);
            gameRepository.save(game7);
            gameRepository.save(game8);

            //Carga de los elementos al repositorio gameplayer
            GamePlayer g1p1 = new GamePlayer(player1, game1);
            GamePlayer g1p2 = new GamePlayer(player2, game1);
            GamePlayer g2p1 = new GamePlayer(player1, game2);
            GamePlayer g2p2 = new GamePlayer(player2, game2);
            GamePlayer g3p2 = new GamePlayer(player2, game3);
            GamePlayer g3p4 = new GamePlayer(player4, game3);
            GamePlayer g4p2 = new GamePlayer(player2, game4);
            GamePlayer g4p1 = new GamePlayer(player1, game4);
            GamePlayer g5p4 = new GamePlayer(player4, game5);
            GamePlayer g5p1 = new GamePlayer(player1, game5);
            GamePlayer g6p3 = new GamePlayer(player3, game6);
            GamePlayer g7p4 = new GamePlayer(player4, game7);
            GamePlayer g8p3 = new GamePlayer(player3, game8);
            GamePlayer g8p4 = new GamePlayer(player4, game8);

            gamePlayerRepository.save(g1p1);
            gamePlayerRepository.save(g1p2);
            gamePlayerRepository.save(g2p1);
            gamePlayerRepository.save(g2p2);
            gamePlayerRepository.save(g3p2);
            gamePlayerRepository.save(g3p4);
            gamePlayerRepository.save(g4p2);
            gamePlayerRepository.save(g4p1);
            gamePlayerRepository.save(g5p4);
            gamePlayerRepository.save(g5p1);
            gamePlayerRepository.save(g6p3);
            gamePlayerRepository.save(g7p4);
            gamePlayerRepository.save(g8p3);
            gamePlayerRepository.save(g8p4);

            //Creación de barcos
            Ship ship1P1G1 = new Ship("Submarine", Arrays.asList("H2", "H3", "H4"), g1p1);
            Ship ship2P1G1 = new Ship("Patrol Boat", Arrays.asList("B4", "B5"), g1p1);
            Ship ship1P2G1 = new Ship("Destroyer", Arrays.asList("B5", "C5", "D5"), g1p2);
            Ship ship2P2G1 = new Ship("Patrol Boat", Arrays.asList("F1", "F2"), g1p2);
            Ship ship1P1G2 = new Ship("Destroyer", Arrays.asList("B5", "C5", "D5"), g2p1);
            Ship ship2P1G2 = new Ship("Patrol Boat", Arrays.asList("C6", "C7"), g2p1);
            Ship ship1P2G2 = new Ship("Submarine", Arrays.asList("A2", "A3", "A4"), g2p2);
            Ship ship2P2G2 = new Ship("Patrol Boat", Arrays.asList("G6", "H6"), g2p2);
            Ship ship1P2G3 = new Ship("Destroyer", Arrays.asList("B5", "C5", "D5"), g3p2);
            Ship ship2P2G3 = new Ship("Patrol Boat", Arrays.asList("C6", "C7"), g3p2);
            Ship ship1P4G3 = new Ship("Submarine", Arrays.asList("A2", "A3", "A4"), g3p4);
            Ship ship2P4G3 = new Ship("Patrol Boat", Arrays.asList("G6", "H6"), g3p4);
            Ship ship1P2G4 = new Ship("Destroyer", Arrays.asList("B5", "C5", "D5"), g4p2);
            Ship ship2P2G4 = new Ship("Patrol Boat", Arrays.asList("C6", "C7"), g4p2);
            Ship ship1P1G4 = new Ship("Submarine", Arrays.asList("A2", "A3", "A4"), g4p1);
            Ship ship2P1G4 = new Ship("Patrol Boat", Arrays.asList("G6", "H6"), g4p1);
            Ship ship1P4G5 = new Ship("Destroyer", Arrays.asList("B5", "C5", "D5"), g5p4);
            Ship ship2P4G5 = new Ship("Patrol Boat", Arrays.asList("C6", "C7"), g5p4);
            Ship ship1P1G5 = new Ship("Submarine", Arrays.asList("A2", "A3", "A4"), g5p1);
            Ship ship2P1G5 = new Ship("Patrol Boat", Arrays.asList("G6", "H6"), g5p1);
            Ship ship1P3G6 = new Ship("Destroyer", Arrays.asList("B5", "C5", "D5"), g6p3);
            Ship ship2P3G6 = new Ship("Patrol Boat", Arrays.asList("C6", "C7"), g6p3);
            Ship ship1P3G8 = new Ship("Destroyer", Arrays.asList("B5", "C5", "D5"), g8p3);
            Ship ship2P3G8 = new Ship("Patrol Boat", Arrays.asList("C6", "C7"), g8p3);
            Ship ship1P4G8 = new Ship("Submarine", Arrays.asList("A2", "A3", "A4"), g8p4);
            Ship ship2P4G8 = new Ship("Patrol Boat", Arrays.asList("G6", "H6"), g8p4);

            shipRepository.save(ship1P1G1);
            shipRepository.save(ship2P1G1);
            shipRepository.save(ship1P2G1);
            shipRepository.save(ship2P2G1);
            shipRepository.save(ship1P1G2);
            shipRepository.save(ship2P1G2);
            shipRepository.save(ship1P2G2);
            shipRepository.save(ship2P2G2);
            shipRepository.save(ship1P2G3);
            shipRepository.save(ship2P2G3);
            shipRepository.save(ship1P4G3);
            shipRepository.save(ship2P4G3);
            shipRepository.save(ship1P2G4);
            shipRepository.save(ship2P2G4);
            shipRepository.save(ship1P1G4);
            shipRepository.save(ship2P1G4);
            shipRepository.save(ship1P4G5);
            shipRepository.save(ship2P4G5);
            shipRepository.save(ship1P1G5);
            shipRepository.save(ship2P1G5);
            shipRepository.save(ship1P3G6);
            shipRepository.save(ship2P3G6);
            shipRepository.save(ship1P3G8);
            shipRepository.save(ship2P3G8);
            shipRepository.save(ship1P4G8);
            shipRepository.save(ship2P4G8);

            //Creación de salvoes
            Salvo salvoP1G1T1 = new Salvo(1, Arrays.asList("B5", "C5", "F1"), g1p1);
            Salvo salvoP1G1T2 = new Salvo(2, Arrays.asList("F2", "D5"), g1p1);
            Salvo salvoP2G1T1 = new Salvo(1, Arrays.asList("B4", "B5", "B6"), g1p2);
            Salvo salvoP2G1T2 = new Salvo(2, Arrays.asList("E1", "H3", "A2"), g1p2);
            Salvo salvoP1G2T1 = new Salvo(1, Arrays.asList("A2", "A4", "G6"), g2p1);
            Salvo salvoP1G2T2 = new Salvo(2, Arrays.asList("A3", "H6"), g2p1);
            Salvo salvoP2G2T1 = new Salvo(1, Arrays.asList("B5", "D5", "C7"), g2p2);
            Salvo salvoP2G2T2 = new Salvo(2, Arrays.asList("C5", "C6"), g2p2);
            Salvo salvoP2G3T1 = new Salvo(1, Arrays.asList("G6", "H6", "A4"), g3p2);
            Salvo salvoP2G3T2 = new Salvo(2, Arrays.asList("A2", "A3", "D8"), g3p2);
            Salvo salvoP4G3T1 = new Salvo(1, Arrays.asList("H1", "H2", "H3"), g3p4);
            Salvo salvoP4G3T2 = new Salvo(2, Arrays.asList("E1", "F2", "G3"), g3p4);
            Salvo salvoP2G4T1 = new Salvo(1, Arrays.asList("A3", "A4", "F7"), g4p2);
            Salvo salvoP2G4T2 = new Salvo(2, Arrays.asList("A2", "G6", "H6"), g4p2);
            Salvo salvoP1G4T1 = new Salvo(1, Arrays.asList("B5", "C6", "H1"), g4p1);
            Salvo salvoP1G4T2 = new Salvo(2, Arrays.asList("C5", "C7", "D5"), g4p1);
            Salvo salvoP4G5T1 = new Salvo(1, Arrays.asList("A1", "A2", "A3"), g5p4);
            Salvo salvoP4G5T2 = new Salvo(2, Arrays.asList("G6", "G7", "G8"), g5p4);
            Salvo salvoP1G5T1 = new Salvo(1, Arrays.asList("B5", "B6", "C7"), g5p1);
            Salvo salvoP1G5T2 = new Salvo(2, Arrays.asList("C6", "D6", "E6"), g5p1);
            Salvo salvoP1G5T3 = new Salvo(3, Arrays.asList("H1", "H8"), g5p1);

            salvoRepository.save(salvoP1G1T1);
            salvoRepository.save(salvoP1G1T2);
            salvoRepository.save(salvoP2G1T1);
            salvoRepository.save(salvoP2G1T2);
            salvoRepository.save(salvoP1G2T1);
            salvoRepository.save(salvoP1G2T2);
            salvoRepository.save(salvoP2G2T1);
            salvoRepository.save(salvoP2G2T2);
            salvoRepository.save(salvoP2G3T1);
            salvoRepository.save(salvoP2G3T2);
            salvoRepository.save(salvoP4G3T1);
            salvoRepository.save(salvoP4G3T2);
            salvoRepository.save(salvoP2G4T1);
            salvoRepository.save(salvoP2G4T2);
            salvoRepository.save(salvoP1G4T1);
            salvoRepository.save(salvoP1G4T2);
            salvoRepository.save(salvoP4G5T1);
            salvoRepository.save(salvoP4G5T2);
            salvoRepository.save(salvoP1G5T1);
            salvoRepository.save(salvoP1G5T2);
            salvoRepository.save(salvoP1G5T3);

        };
    }

}