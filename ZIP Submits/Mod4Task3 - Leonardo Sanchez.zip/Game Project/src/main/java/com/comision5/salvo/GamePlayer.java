package com.comision5.salvo;


import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Entity
public class GamePlayer {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "native")
    @GenericGenerator(name = "native", strategy = "native")
    private long id;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "player_id")
    private Player player;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "game_id")
    private Game game;

    @OneToMany(mappedBy = "gamePlayer")
    private List<Ship> ships;

    private Date joinTime;

    public GamePlayer() {
        this.joinTime = new Date();
    }

    public GamePlayer(Player player, Game game) {
        this.joinTime = new Date();
        this.player = player;
        this.game = game;
    }

    public long getId() {
        return id;
    }

    public Date getJoinTime() {
        return joinTime;
    }

    @JsonIgnore
    public Player getPlayer() {
        return player;
    }

    public void setPlayer(Player player) {
        this.player = player;
    }

    @JsonIgnore
    public Game getGame() {
        return game;
    }

    public void setGame(Game game) {
        this.game = game;
    }

    //Devuelve la lista de barcos
    @JsonIgnore
    public List<Ship> getShips() {
        return ships;
    }

    //agrega elementos a la lista de barcos
    public void addShips(Ship ship) {
        this.ships.add(ship);
    }

    //Saca unidades de la lisa de barcos
    public void removeShips(Ship ship) {
        this.ships.remove(ship);
    }
}
