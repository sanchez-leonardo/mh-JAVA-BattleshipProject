package com.comision5.salvo;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Entity
public class Game {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "native")
    @GenericGenerator(name = "native", strategy = "native")
    private long id;

    @OneToMany(mappedBy = "game", fetch = FetchType.EAGER)
    private List<GamePlayer> gamePlayers;

    private Date gameTime;

    public Game() {
        this.gameTime = new Date();
    }

    public Game(Date gameTime) {
        this.gameTime = gameTime;
    }

    public long getId() {
        return this.id;
    }

    public Date getGameTime() {
        return this.gameTime;
    }

    //Devuelve el objeto lista y no sus elementos
    public List<GamePlayer> getGamePlayers() {
        return gamePlayers;
    }

    public void addGamePlayers(GamePlayer gamePlayers) {
        gamePlayers.setGame(this);
        this.gamePlayers.add(gamePlayers);
    }
}
