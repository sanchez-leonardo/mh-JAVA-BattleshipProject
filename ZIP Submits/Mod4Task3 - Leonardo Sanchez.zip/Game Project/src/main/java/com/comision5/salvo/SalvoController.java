package com.comision5.salvo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api")
public class SalvoController {

    @Autowired
    private GameRepository gameRepository;

    @RequestMapping("/games")
    public List<Object> gamesInfo() {
        return gameRepository.findAll().stream().map(this::gameDetail).collect(Collectors.toList());
    }

    @Autowired
    private GamePlayerRepository gamePlayerRepository;

    //Pedido especial para generar una lista en el DOM, solo por facilidad propia dado que soy amo y señor de este proyecto
    @RequestMapping("/gamePlayerIds")
    private List<Object> gamePlayerIds(){
        return gamePlayerRepository.findAll().stream().map(gp -> gp.getId()).collect(Collectors.toList());
    }

    @RequestMapping("/game_view/{id}")
    private Map<String, Object> gameView(@PathVariable long id) {

        GamePlayer gamePlayer = gamePlayerRepository.findById(id).get();
        return gameByID(gamePlayer);
    }

    //Extraer la info de cada juego
    private Map<String, Object> gameDetail(Game game) {

        Map<String, Object> gameDTO = new LinkedHashMap<>();

        gameDTO.put("id", game.getId());
        gameDTO.put("created", game.getGameTime());
        gameDTO.put("game_players", game.getGamePlayers().stream().map(this::gamePlayerDetail).collect(Collectors.toList()));

        return gameDTO;
    }

    //Extrae gamePlayers Ids, creation y players
    private Map<String, Object> gamePlayerDetail(GamePlayer gamePlayer) {

        Map<String, Object> gamePlayerDTO = new LinkedHashMap<>();

        gamePlayerDTO.put("id", gamePlayer.getId());
        gamePlayerDTO.put("player", playerDetail(gamePlayer.getPlayer()));

        return gamePlayerDTO;
    }

    //Extrae Player IDs y Username
    private Map<String, Object> playerDetail(Player player) {

        Map<String, Object> playerDTO = new LinkedHashMap<>();

        playerDTO.put("id", player.getId());
        playerDTO.put("email", player.getUserName());

        return playerDTO;
    }

    //Extraccion de obj con ships
    private Map<String, Object> gameByID(GamePlayer gamePlayer) {

        Map<String, Object> gamePlayerDTO = new LinkedHashMap<>();

        gamePlayerDTO.put("game_id", gamePlayer.getGame().getId());
        gamePlayerDTO.put("game_creation", gamePlayer.getGame().getGameTime());
        gamePlayerDTO.put("game_players", gamePlayerArray(gamePlayer.getGame()));
        gamePlayerDTO.put("ships", playerShips(gamePlayer.getShips()));

        return gamePlayerDTO;

    }

    //Array de gamePLayers
    private List<Object> gamePlayerArray(Game game) {

        return game.getGamePlayers().stream().map(gp -> {

            Map<String, Object> gamePlayerDTO = new LinkedHashMap<>();

            gamePlayerDTO.put("game_player_id", gp.getId());
            gamePlayerDTO.put("game_player_join_date", gp.getJoinTime());
            gamePlayerDTO.put("player_detail", playerDetail(gp.getPlayer()));

            return gamePlayerDTO;
        }).collect(Collectors.toList());

    }

    //Ship Arrays
    private List<Object> playerShips(List<Ship> ships) {

        return ships.stream().map(ship -> {
            Map<String, Object> shipDTO = new LinkedHashMap<>();

            shipDTO.put("type", ship.getShipType());
            shipDTO.put("locations", ship.getShipLocation());

            return shipDTO;
        }).collect(Collectors.toList());

    }


}