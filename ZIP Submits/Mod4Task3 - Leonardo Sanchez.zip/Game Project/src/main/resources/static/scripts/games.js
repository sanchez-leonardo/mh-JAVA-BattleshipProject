//Script para render de info de todos juegos (task3)

// let gamesTable = document.getElementById('games-table');

// let gameData;

// window.onLoad = fetch('/api/games')
//   .then(response => response.json())
//   .then(data => {
//     gameData = data;
//   });

// function renderListItems(data) {
//   data.forEach(element => {
//     let gameContainer = document.createElement('li');

//     let gameUl = document.createElement('ul');

//     let gameIdLi = document.createElement('li');
//     gameIdLi.innerText = 'Game Id: ' + element.id;

//     let creationDateLi = document.createElement('li');
//     creationDateLi.innerText = 'Created: ' + element.created;

//     let gamePlayersLi = document.createElement('li');
//     gamePlayersLi.innerText = 'Players: ';

//     let playersUl = document.createElement('ul');

//     element.gamePlayers.map(player => {
//       let playerLi = document.createElement('li');
//       playerLi.innerText = player.player.email;
//       playersUl.appendChild(playerLi);
//     });

//     gamePlayersLi.appendChild(playersUl);

//     let gameItems = [gameIdLi, creationDateLi, gamePlayersLi];

//     gameUl.append(...gameItems);

//     gameContainer.appendChild(gameUl);

//     gamesTable.appendChild(gameContainer);
//   });
// }

//-----------------------------------------------------------------------------------

//Función de creación de la grilla
//Por cada letra crea una linea y le pone id's y clases
function createGrid() {
  //Contenedor de la grilla
  let grid = document.getElementById('game-grid');
  //Patrón de letras
  let gridLetters = ['0', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j'];

  gridLetters.forEach((letter, i) => {
    let squareLine = document.createElement('div');
    squareLine.setAttribute('class', 'grid-line ' + letter);

    for (i = 0; i < 11; i++) {
      let square = document.createElement('div');
      square.setAttribute('id', letter + i);
      square.setAttribute('class', 'grid-square');

      if (square.getAttribute('id') == '00') {
        square.classList.add('blank');
      } else if (letter === '0') {
        square.classList.add('column-name');
        square.innerHTML = `<p>${i}</p>`;
      } else if (i === 0) {
        square.classList.add('column-num');
        square.innerHTML = `<p>${letter.toUpperCase()}</p>`;
      }

      squareLine.appendChild(square);
    }

    grid.appendChild(squareLine);
  });
}

//Pedido de GP ids para menu select
//Usa un fetch a una ruta no pedida en el task
let gamePlayerIdsSelect = document.getElementById('gpSelect');

function createIdSelect() {
  fetch('/api/gamePlayerIds')
    .then(response => response.json())
    .then(data => menuOptions(gamePlayerIdsSelect, data));
}

//Función creadora de opciones, necesita un target y array de opciones
function menuOptions(menu, source) {
  source.forEach(opt => {
    let option = document.createElement('option');
    option.innerText = opt;
    option.setAttribute('value', opt);

    menu.appendChild(option);
  });
}

//-----------------------------------------------------------------------------------

//Función que captura el query string y realiza el pedido de datos si los hay
function searchByQueryString() {
  let queryStringGP = getQueryVariable('gp');

  if (queryStringGP) {
    fetch('/api/game_view/' + queryStringGP)
      .then(response => response.json())
      .then(data => {
        data.ships.forEach(ship => paintThemShips(ship));
        playerNames(data, queryStringGP);
      });
  }
}

//Función de pedido de game player por formulario
//No es necesario para el task, es una función de prueba

//Almacenaje de datos para prueba
//let gpById;

function searchByForm() {
  event.preventDefault();

  //Esta parte saca los barcos si habia alguno previamente
  document
    .querySelectorAll('.grid-square')
    .forEach(square => square.classList.remove('ship-piece'));

  let gpId = document.getElementById('gpSelect').value;

  if (gpId != 'none') {
    fetch('/api/game_view/' + gpId)
      .then(response => response.json())
      .then(data => {
        //gpById = data;
        data.ships.forEach(ship => paintThemShips(ship));
        playerNames(data, gpId);
      });
  } else {
    alert('No game player selected');
  }
}

//Función que cambia el color si hay una pieza de barco
function paintThemShips(ship) {
  ship.locations.forEach(square => {
    document.getElementById(square.toLowerCase()).classList.add('ship-piece');
  });
}

//Función que coloca nombre de los jugadores
function playerNames(data, gpId) {
  let p1Name = document.getElementById('player1');
  let p2Name = document.getElementById('player2');

  data.game_players.forEach(gp => {
    if (gp.game_player_id == gpId) {
      p1Name.innerText = gp.player_detail.email;
    } else {
      p2Name.innerText = gp.player_detail.email;
    }
  });
}

//-----------------------------------------------------------------------------------

//Utilities

//Función que captura el valor de una variable del query string
function getQueryVariable(variable) {
  var query = window.location.search.substring(1);
  var vars = query.split('&');
  for (var i = 0; i < vars.length; i++) {
    var pair = vars[i].split('=');
    if (pair[0] == variable) {
      return pair[1];
    }
  }
  return false;
}

//Función que devuelve un objeto key-value del query string
function paramObj(search) {
  var obj = {};
  var reg = /(?:[?&]([^?&#=]+)(?:=([^&#]*))?)(?:#.*)?/g;

  search.replace(reg, function(match, param, val) {
    obj[decodeURIComponent(param)] =
      val === undefined ? '' : decodeURIComponent(val);
  });

  return obj;
}

//LLamado a las funciones cuando carga la ventana
window.onload = function() {
  createGrid();
  createIdSelect();
  searchByQueryString();
};
