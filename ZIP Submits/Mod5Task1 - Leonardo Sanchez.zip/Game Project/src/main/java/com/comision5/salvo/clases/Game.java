package com.comision5.salvo.clases;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Entity
public class Game {

  @Id
  @GeneratedValue(strategy = GenerationType.AUTO, generator = "native")
  @GenericGenerator(name = "native", strategy = "native")
  private long id;

  @OneToMany(mappedBy = "game", fetch = FetchType.EAGER)
  private List<GamePlayer> gamePlayers;

  @OneToMany(mappedBy = "game", fetch = FetchType.EAGER)
  private List<Score> scores;

  private Date gameCreation;


  public Game() {
    this.gameCreation = new Date();
  }

  public Game(Date gameTime) {
    this.gameCreation = gameTime;
  }


  public long getId() {
    return this.id;
  }

  public Date getGameCreation() {
    return this.gameCreation;
  }

  public List<GamePlayer> getGamePlayers() {
    return gamePlayers;
  }

  public void setGamePlayers(List<GamePlayer> gamePlayers) {
    this.gamePlayers = gamePlayers;
  }

  public List<Score> getScores() {
    return scores;
  }

  public void setScores(List<Score> scores) {
    this.scores = scores;
  }


  //Métodos para generar DTOs
  //Extraer la info de cada juego
  public Map<String, Object> gameDTO() {

    Map<String, Object> gameDTO = new LinkedHashMap<>();

    gameDTO.put("id", getId());
    gameDTO.put("created", getGameCreation());
    gameDTO.put("game_players", getGamePlayers().stream().map(GamePlayer::gamePlayerDetail).collect(Collectors.toList()));

    return gameDTO;
  }

  //Game Player List para gamePlayerDTO en /game_view
  public List<Object> gamePlayerArray() {

    return getGamePlayers().stream().map(GamePlayer::gamePlayerObject).collect(Collectors.toList());

  }

  //Salvoes per player in a game object para /game view
  public Map<Long, Object> salvoesByPlayer() {

    return getGamePlayers().stream().collect(Collectors.toMap(gp -> gp.getPlayer().getId(),
            GamePlayer::salvoesByTurn, (s, a) -> s + ", " + a, LinkedHashMap::new));
  }
}
