package com.comision5.salvo;

import com.comision5.salvo.clases.*;
import com.comision5.salvo.restrepositories.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api")
public class SalvoController {

  @Autowired
  private GameRepository gameRepo;

  @Autowired
  private PlayerRepository playerRepo;

  @Autowired
  private GamePlayerRepository gamePlayerRepo;

  @Autowired
  private PasswordEncoder passwordEncoder;


  @GetMapping("/games")
  public Map<String, Object> gamesInfo(Authentication auth) {

    boolean isGuest = auth == null;

    Map<String, Object> gamesInfoDTO = new LinkedHashMap<>();

    gamesInfoDTO.put("currentUser", isGuest ? null  : playerRepo.findByUserName(auth.getName()).playerDetail());
    gamesInfoDTO.put("games", gameRepo.findAll().stream().map(Game::gameDTO).collect(Collectors.toList()));

    return gamesInfoDTO;
  }

  @GetMapping("/game_view/{id}")
  private Map<String, Object> gameView(@PathVariable long id) {
    return gamePlayerRepo.findById(id).get().gamePlayerDTO();
  }

  //No es extrictamente necesario pero es el otro camino para crear la tabla de puntajes
  @GetMapping("/leaderboard")
  public List<Object> lederboardInfo() {
    return playerRepo.findAll().stream().map(Player::leaderBoardDTO).collect(Collectors.toList());
  }

  //Pedido especial para generar una lista en el DOM, solo por facilidad propia dado que soy amo y señor de este proyecto
  @GetMapping("/gamePlayerIds")
  private List<Object> gamePlayerIds() {
    return gamePlayerRepo.findAll().stream().map(GamePlayer::getId).collect(Collectors.toList());
  }

  //Registro de usuario
  @PostMapping(path = "/players")
  public ResponseEntity<Object> register(
          @RequestParam String userName, @RequestParam String password) {

    if (userName.isEmpty() || password.isEmpty()) {
      return new ResponseEntity<>("Missing data", HttpStatus.FORBIDDEN);
    }

    if (playerRepo.findByUserName(userName) != null) {
      return new ResponseEntity<>("Email already in use", HttpStatus.FORBIDDEN);
    }

    playerRepo.save(new Player(userName, passwordEncoder.encode(password)));
    return new ResponseEntity<>(HttpStatus.CREATED);
  }


}