//Register/Log in/log out
let multiForm = document.getElementById('multiForm');

let registerBtn = document.getElementById('registerBtn');

let signInBtn = document.getElementById('signInBtn');

let logOutBtn = document.getElementById('logOutBtn');

async function postingFetch(url, body = '') {
  let init = {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
    },
    body: body
  };

  try {
    const response = await fetch(url, init);
    return response.status;
  } catch (error) {
    return console.log(error);
  }
}

function emailIsValid(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

//register fetch
function registerUser() {
  if (emailIsValid(multiForm.userName.value)) {
    let formFields =
      'userName=' +
      encodeURIComponent(multiForm.userName.value) +
      '&password=' +
      multiForm.password.value;

    postingFetch('/api/players', formFields)
      .then(data => {
        data == 201 ? signInUser() : console.log(data);
      })
      .catch(error => console.log(error));
  } else {
    alert('Email must contain one "@" and a valid domain name');
  }
}

//Sign In fetch
function signInUser() {
  if (emailIsValid(multiForm.userName.value)) {
    let formFields =
      'userName=' +
      encodeURIComponent(multiForm.userName.value) +
      '&password=' +
      multiForm.password.value;

    postingFetch('/api/login', formFields)
      .then(data => {
        data == 200 ? location.reload() : console.log(data);
      })
      .catch(error => console.log(error));
  } else {
    alert('User name is invalid');
  }
}

//log out fetch
function logOut(evt) {
  evt.preventDefault();

  postingFetch('/api/logout')
    .then(data => {
      data == 200 ? location.reload() : console.log(data);
    })
    .catch(error => console.log(error));
}

multiForm.addEventListener('submit', evt => evt.preventDefault());

registerBtn.addEventListener('click', registerUser);

signInBtn.addEventListener('click', signInUser);

logOutBtn.addEventListener('click', logOut);

//-----------------------------------------------------------------------------------
//Conditional Rendering
let forUser = Array.from(document.getElementsByClassName('authenticated'));

let forAnnon = Array.from(document.getElementsByClassName('annon'));

let playerSpan = document.getElementById('playerSpan');

function conditionalRender(user) {
  if (user == null) {
    console.log('Unauthorized');
  } else {
    forUser.forEach(e => e.classList.remove('authenticated'));
    forAnnon.forEach(e => {
      e.classList.add('authenticated');
      e.classList.remove('annon');
    });

    playerSpan.innerText = gamesCallData.currentUser.email;
  }
}

//-----------------------------------------------------------------------------------
//Games Info y creación de leaderboard
//Variable de datos
let gamesCallData;

function gamesInfo() {
  fetch('/api/games')
    .then(response => response.json())
    .then(data => {
      gamesCallData = data;
      conditionalRender(gamesCallData.currentUser);
    })
    .catch(error => console.log(error));
}

//Generación de la tabla de leaderboard desde la llamada a /leaderboard
//Variables para testeo
let leaderboardCallData;

function leaderboardFromLeaderboardRequest() {
  fetch('/api/leaderboard')
    .then(response => response.json())
    .then(data => {
      leaderboardCallData = data;
      createLeaderboard2(data);
    });
}

//Crea una tabla de posiciones segun el llamado a /leaderboard
function createLeaderboard2(data) {
  let tableBody = document.getElementById('leaderboard-table');

  data.forEach(player => {
    if (player.scores.matches != 0) {
      let tRow = document.createElement('tr');

      let nameCell = document.createElement('td');
      nameCell.innerText = player.email;

      let totalCell = document.createElement('td');
      totalCell.innerText = player.scores.total;

      let winCell = document.createElement('td');
      winCell.innerText = player.scores.win;

      let looseCell = document.createElement('td');
      looseCell.innerText = player.scores.loose;

      let tieCell = document.createElement('td');
      tieCell.innerText = player.scores.tie;

      let cells = [nameCell, totalCell, winCell, looseCell, tieCell];

      tRow.append(...cells);

      tableBody.appendChild(tRow);
    }
  });
}

//-----------------------------------------------------------------------------------

//Extra
//Pedido de GP ids para menu select
//Usa un fetch a una ruta no pedida en el task
let gamePlayerIdsSelect = document.getElementById('gpSelect');

function fetchIdsList() {
  fetch('/api/gamePlayerIds')
    .then(response => response.json())
    .then(data => menuOptions(gamePlayerIdsSelect, data));
}

//Función creadora de opciones, necesita un target y array de opciones
function menuOptions(menu, source) {
  source.forEach(opt => {
    let option = document.createElement('option');
    option.innerText = opt;
    option.setAttribute('value', opt);

    menu.appendChild(option);
  });
}

//-----------------------------------------------------------------------------------

//Función que captura el query string y realiza el pedido de datos si los hay
//Almacenaje de datos para prueba
let gpById;

function fetchByQueryString() {
  let queryStringGP = getQueryVariable('gp');

  if (queryStringGP) {
    fetch('/api/game_view/' + queryStringGP)
      .then(response => response.json())
      .then(data => {
        gpById = data;
        data.ships.forEach(ship => paintThemShips(ship));
        playerNames(data, queryStringGP);
        paintThemSalvoes(data, queryStringGP);
        paintThemHits(data, queryStringGP);
      });
  }
}

//Función de pedido de game player por formulario
//No es necesario para el task, es una función de prueba
function searchByForm() {
  event.preventDefault();

  let gpId = document.getElementById('gpSelect').value;

  if (gpId != 'none') {
    window.location.search = '?gp=' + gpId;
  } else {
    alert('No game player selected');
  }
}

//-----------------------------------------------------------------------------------

//Función de creación de la grilla, recibe Id de contenedor y target para player o salvo
//Por cada letra crea una linea y le pone id's y clases
function createGrid(id, target) {
  //Contenedor de la grilla
  let grid = document.getElementById(id);
  //Patrón de letras
  let gridLetters = ['0', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j'];

  gridLetters.forEach((letter, i) => {
    let squareLine = document.createElement('div');
    squareLine.setAttribute('class', 'grid-line ' + letter);

    for (i = 0; i < 11; i++) {
      let square = document.createElement('div');
      square.setAttribute('id', target + letter + i);
      square.setAttribute('class', 'grid-square');

      if (
        square.getAttribute('id') == 's00' ||
        square.getAttribute('id') == 'p00'
      ) {
        square.classList.add('blank');
      } else if (letter === '0') {
        square.classList.add('column-name');
        square.innerHTML = `<p>${i}</p>`;
      } else if (i === 0) {
        square.classList.add('column-num');
        square.innerHTML = `<p>${letter.toUpperCase()}</p>`;
      }

      squareLine.appendChild(square);
    }

    grid.appendChild(squareLine);
  });
}

//Función que cambia el color si hay una pieza de barco en player's grid
function paintThemShips(ship) {
  ship.locations.forEach(location => {
    document
      .getElementById('p' + location.toLowerCase())
      .classList.add('ship-piece');
  });
}

//Función que marca salvoes en salvo's grid
function paintThemSalvoes(data, gamePlayerId) {
  let p1Id = data.game_players.filter(
    gp => gp.game_player_id == gamePlayerId
  )[0].player_detail.id;

  Object.entries(data.salvoes[p1Id]).forEach(turn => {
    turn[1].forEach(location => {
      salvoLocation = document.getElementById('s' + location.toLowerCase());
      salvoLocation.classList.add('salvo');
      salvoLocation.innerHTML = `<p>${turn[0]}</p>`;
    });
  });
}

//Función de hits
function paintThemHits(data, gamePlayerId) {
  let p2Id = data.game_players.filter(
    gp => gp.game_player_id != gamePlayerId
  )[0].player_detail.id;

  Object.entries(data.salvoes[p2Id]).forEach(turn => {
    turn[1].forEach(location => {
      hitLocation = document.getElementById('p' + location.toLowerCase());

      if (hitLocation.classList.contains('ship-piece')) {
        hitLocation.classList.add('hit');
        hitLocation.innerHTML = `<p>${turn[0]}</p>`;
      }
    });
  });
}

//Función que coloca nombre de los jugadores
function playerNames(data, gpId) {
  let p1Name = document.getElementById('player1');
  let p2Name = document.getElementById('player2');

  data.game_players.forEach(gp => {
    if (gp.game_player_id == gpId) {
      p1Name.innerText = gp.player_detail.email;
    } else {
      p2Name.innerText = gp.player_detail.email;
    }
  });
}

//-----------------------------------------------------------------------------------

//Utilities

//Función que captura el valor de una variable del query string
function getQueryVariable(variable) {
  var query = window.location.search.substring(1);
  var vars = query.split('&');
  for (var i = 0; i < vars.length; i++) {
    var pair = vars[i].split('=');
    if (pair[0] == variable) {
      return pair[1];
    }
  }
  return false;
}

//-----------------------------------------------------------------------------------

//LLamado a las funciones cuando carga la ventana
window.onload = function() {
  gamesInfo();
  leaderboardFromLeaderboardRequest();
  fetchIdsList();
  fetchByQueryString();
  createGrid('salvos-grid', 's');
  createGrid('player-grid', 'p');
};
